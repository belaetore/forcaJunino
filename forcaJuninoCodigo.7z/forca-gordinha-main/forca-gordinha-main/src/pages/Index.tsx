
import JogoForca from '../components/JogoForca';

const Index = () => {
  return <JogoForca />;
};

export default Index;
