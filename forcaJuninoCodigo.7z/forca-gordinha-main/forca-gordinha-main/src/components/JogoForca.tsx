
import React, { useState, useEffect } from 'react';

const palavrasJuninas = [
  { palavra: 'QUADRILHA', dica: 'Dança típica das festas juninas' },
  { palavra: 'FOGUEIRA', dica: 'Fogo grande que aquece a festa' },
  { palavra: 'MILHO', dica: 'Grão amarelo muito consumido em junho' },
  { palavra: 'PAMONHA', dica: 'Doce feito com milho ralado' },
  { palavra: 'QUENTAO', dica: 'Bebida quente com gengibre e canela' },
  { palavra: 'BANDEIRINHA', dica: 'Decoração colorida pendurada' },
  { palavra: 'CASAMENTO', dica: 'Cerimônia encenada na festa' },
  { palavra: 'SANFONA', dica: 'Instrumento musical de fole' },
  { palavra: 'VIOLEIRO', dica: 'Músico que toca viola' },
  { palavra: 'CANJICA', dica: 'Doce branco feito com milho' },
  { palavra: 'PIPOCA', dica: 'Milho que estoura no fogo' },
  { palavra: 'CAIPIRA', dica: 'Pessoa do interior, rural' },
  { palavra: 'FESTA', dica: 'Celebração alegre' },
  { palavra: 'JUNHO', dica: 'Mês das festas juninas' },
  { palavra: 'JULINA', dica: 'Festa que acontece em julho' },
  { palavra: 'DANCA', dica: 'Movimento ritmado do corpo' },
  { palavra: 'ARRAIA', dica: 'Outro nome para festa junina' },
  { palavra: 'BALAO', dica: 'Objeto que voa no céu (perigoso!)' },
  { palavra: 'FOGUETE', dica: 'Rojão que faz barulho' },
  { palavra: 'AMENDOIM', dica: 'Semente torrada e salgada' },
  { palavra: 'ZABUMBA', dica: 'Tambor grande usado no forró' },
  { palavra: 'TRIANGULO', dica: 'Instrumento de metal que faz ting' }
];

const JogoForca: React.FC = () => {
  const [palavraAtual, setPalavraAtual] = useState({ palavra: '', dica: '' });
  const [letrasAdivinhadas, setLetrasAdivinhadas] = useState<string[]>([]);
  const [letrasErradas, setLetrasErradas] = useState<string[]>([]);
  const [erros, setErros] = useState(0);
  const [dicasUsadas, setDicasUsadas] = useState(0);
  const [mostrarDica, setMostrarDica] = useState(false);
  const maxErros = 6;
  const maxDicas = 3;

  const iniciarJogo = () => {
    const palavraAleatoria = palavrasJuninas[Math.floor(Math.random() * palavrasJuninas.length)];
    setPalavraAtual(palavraAleatoria);
    setLetrasAdivinhadas([]);
    setLetrasErradas([]);
    setErros(0);
    setDicasUsadas(0);
    setMostrarDica(false);
  };

  useEffect(() => {
    iniciarJogo();
  }, []);

  const palavraCompleta = palavraAtual.palavra.split('').every(letra => letrasAdivinhadas.includes(letra));
  const jogoTerminado = erros >= maxErros || palavraCompleta;

  const tentarLetra = (letra: string) => {
    if (letrasAdivinhadas.includes(letra) || letrasErradas.includes(letra) || jogoTerminado) {
      return;
    }

    if (palavraAtual.palavra.includes(letra)) {
      setLetrasAdivinhadas([...letrasAdivinhadas, letra]);
    } else {
      setLetrasErradas([...letrasErradas, letra]);
      setErros(erros + 1);
    }
  };

  const usarDica = () => {
    if (dicasUsadas < maxDicas && !jogoTerminado) {
      setDicasUsadas(dicasUsadas + 1);
      setMostrarDica(true);
    }
  };

  const renderizarPalavra = () => {
    return palavraAtual.palavra.split('').map((letra, index) => (
      <div
        key={index}
        className="w-12 h-16 border-b-4 border-terra flex items-center justify-center mx-1 mb-4"
      >
        <span className="text-3xl font-black text-carvao">
          {letrasAdivinhadas.includes(letra) ? letra : ''}
        </span>
      </div>
    ));
  };

  const renderizarTeclado = () => {
    const alfabeto = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
    
    return (
      <div className="grid grid-cols-7 gap-2 max-w-lg mx-auto">
        {alfabeto.map(letra => {
          const foiUsada = letrasAdivinhadas.includes(letra) || letrasErradas.includes(letra);
          const acertou = letrasAdivinhadas.includes(letra);
          const errou = letrasErradas.includes(letra);
          
          return (
            <button
              key={letra}
              onClick={() => tentarLetra(letra)}
              disabled={foiUsada || jogoTerminado}
              className={`
                w-10 h-10 rounded-lg font-black text-lg transition-all duration-200 text-shadow
                ${foiUsada 
                  ? acertou 
                    ? 'bg-green-600 text-white cursor-not-allowed' 
                    : 'bg-red-600 text-white cursor-not-allowed'
                  : 'bg-creme text-carvao hover:bg-palha hover:scale-105 active:scale-95 cursor-pointer shadow-md'
                }
                ${jogoTerminado && !foiUsada ? 'opacity-50 cursor-not-allowed' : ''}
              `}
            >
              {letra}
            </button>
          );
        })}
      </div>
    );
  };

  const renderizarBonecoStick = () => {
    const partes = [
      // Base da forca
      <div key="base" className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-16 h-2 bg-barro rounded"></div>,
      // Poste vertical
      <div key="poste" className="absolute bottom-2 left-1/2 transform -translate-x-1/2 w-2 h-20 bg-barro rounded"></div>,
      // Trave horizontal
      <div key="trave" className="absolute top-2 left-1/2 transform -translate-x-1/2 translate-x-6 w-12 h-2 bg-barro rounded"></div>,
      // Corda
      <div key="corda" className="absolute top-4 left-1/2 transform -translate-x-1/2 translate-x-12 w-1 h-6 bg-barro"></div>,
      // Cabeça (centralizada)
      <div key="cabeca" className="absolute top-10 left-1/2 transform -translate-x-1/2 translate-x-12 w-6 h-6 border-4 border-carvao rounded-full bg-transparent"></div>,
      // Corpo (centralizado)
      <div key="corpo" className="absolute top-16 left-1/2 transform -translate-x-1/2 translate-x-12 w-1 h-12 bg-carvao"></div>,
      // Braço esquerdo (saindo do meio do corpo para a esquerda)
      <div key="braco1" className="absolute top-20 left-1/2 transform -translate-x-1/2 translate-x-6 w-6 h-1 bg-carvao"></div>,
      // Braço direito (saindo do meio do corpo para a direita)
      <div key="braco2" className="absolute top-20 left-1/2 transform -translate-x-1/2 translate-x-12 w-6 h-1 bg-carvao"></div>,
      // Perna esquerda (saindo do final do corpo para a esquerda)
      <div key="perna1" className="absolute top-28 left-1/2 transform -translate-x-1/2 translate-x-6 w-6 h-1 bg-carvao"></div>,
      // Perna direita (saindo do final do corpo para a direita)
      <div key="perna2" className="absolute top-28 left-1/2 transform -translate-x-1/2 translate-x-12 w-6 h-1 bg-carvao"></div>
    ];
    
    return (
      <div className="bg-madeira rounded-xl p-6 shadow-lg relative h-40 w-32">
        {partes.slice(0, Math.min(4 + erros, partes.length)).map(parte => parte)}
      </div>
    );
  };

  return (
    <div className="h-screen flex flex-col justify-center items-center p-4 font-nunito">
      <div className="max-w-4xl w-full">
        {/* Título */}
        <div className="text-center mb-6">
          <h1 className="text-4xl md:text-6xl font-black text-terra text-shadow mb-2">
            FORCA JUNINA
          </h1>
          <p className="text-xl font-bold text-barro">
            Adivinhe a palavra da festa!
          </p>
        </div>

        {/* Área do jogo */}
        <div className="grid md:grid-cols-3 gap-6 items-start">
          {/* Forca */}
          <div className="flex justify-center">
            {renderizarBonecoStick()}
          </div>

          {/* Palavra e controles */}
          <div className="space-y-4">
            {/* Palavra */}
            <div className="flex justify-center flex-wrap">
              {renderizarPalavra()}
            </div>

            {/* Status do jogo */}
            <div className="text-center">
              <p className="text-lg font-bold text-barro mb-2">
                Erros: {erros}/{maxErros}
              </p>
              
              {jogoTerminado && (
                <div className="mb-4">
                  {palavraCompleta ? (
                    <p className="text-2xl font-black text-green-700">
                      PARABÉNS! VOCÊ VENCEU!
                    </p>
                  ) : (
                    <div>
                      <p className="text-2xl font-black text-red-700 mb-2">
                        VOCÊ PERDEU!
                      </p>
                      <p className="text-lg font-bold text-barro">
                        A palavra era: <span className="text-terra">{palavraAtual.palavra}</span>
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Botão novo jogo */}
            <div className="text-center">
              <button
                onClick={iniciarJogo}
                className="bg-terra text-creme px-6 py-2 rounded-xl font-black text-lg hover:bg-barro transition-all duration-200 hover:scale-105 active:scale-95 shadow-lg text-shadow"
              >
                NOVO JOGO
              </button>
            </div>
          </div>

          {/* Seção de Dicas */}
          <div className="bg-palha rounded-xl p-4 shadow-lg">
            <h3 className="text-lg font-black text-terra mb-3 text-center">
              DICAS
            </h3>
            
            <div className="text-center mb-3">
              <p className="text-sm font-bold text-barro">
                Dicas restantes: {maxDicas - dicasUsadas}
              </p>
            </div>

            <button
              onClick={usarDica}
              disabled={dicasUsadas >= maxDicas || jogoTerminado}
              className={`
                w-full py-2 px-4 rounded-lg font-black text-sm transition-all duration-200
                ${dicasUsadas >= maxDicas || jogoTerminado
                  ? 'bg-gray-400 text-gray-600 cursor-not-allowed'
                  : 'bg-terra text-creme hover:bg-barro hover:scale-105 active:scale-95 shadow-md'
                }
              `}
            >
              {dicasUsadas >= maxDicas ? 'SEM DICAS' : 'USAR DICA'}
            </button>

            {mostrarDica && (
              <div className="mt-4 p-3 bg-creme rounded-lg border-2 border-terra">
                <p className="text-sm font-bold text-carvao text-center">
                  {palavraAtual.dica}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Teclado */}
        <div className="mt-6">
          <h3 className="text-center text-lg font-bold text-barro mb-4">
            Clique nas letras:
          </h3>
          {renderizarTeclado()}
        </div>
      </div>
    </div>
  );
};

export default JogoForca;
