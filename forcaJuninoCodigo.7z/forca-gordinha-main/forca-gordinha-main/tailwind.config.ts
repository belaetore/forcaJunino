
import type { Config } from "tailwindcss";

export default {
	darkMode: ["class"],
	content: [
		"./pages/**/*.{ts,tsx}",
		"./components/**/*.{ts,tsx}",
		"./app/**/*.{ts,tsx}",
		"./src/**/*.{ts,tsx}",
	],
	prefix: "",
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1400px'
			}
		},
		extend: {
			fontFamily: {
				'nunito': ['Nunito', 'sans-serif'],
			},
			colors: {
				// Cores neutras e juninas
				'terra': '#8B4513',
				'areia': '#F4E4BC',
				'ferrugem': '#CD853F',
				'barro': '#A0522D',
				'palha': '#DEB887',
				'madeira': '#D2691E',
				'carvao': '#2F2F2F',
				'creme': '#FFF8DC',
			},
		}
	},
	plugins: [],
} satisfies Config;
